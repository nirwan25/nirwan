<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.css">
    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800,900" rel="stylesheet">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="images/sidebar-05/css/style.css">
    <link rel="stylesheet" href="gaya.css">
    <link href="//netdna.bootstrapcdn.com/bootstrap/3.0.3/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <script src="//netdna.bootstrapcdn.com/bootstrap/3.0.3/js/bootstrap.min.js"></script>
    <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>

    <title>Admin</title>
</head>
<body>

<!-- Sidebar -->
	
<div class="wrapper d-flex align-items-stretch">
			<nav id="sidebar">
				<div class="custom-menu">
					<button type="button" id="sidebarCollapse" class="btn btn-primary">
	          <i class="fa fa-bars"></i>
	          <span class="sr-only">laundry Menu</span>
	        </button>
        </div>
				<div class="p-4">
		  		<h1><a href="index.html" class="logo">laundry<span>layanan untuk anda</span></a></h1>
	        <ul class="list-unstyled components mb-5">
	          <li class="active">
	            <a href="dashboard.php"><span class="fa fa-home mr-3"></span> Home</a>
	          </li>
	          <li>
	              <a href="#"><span class="fa fa-user mr-3"></span>transaksi</a>
	          </li>
	          <li>
              <a href="#"><span class="fa fa-briefcase mr-3"></span> data pmesanan</a>
	          </li>
              </li>
              
	        </ul>

	        <div class="mb-5">
						
</form>
	</div>
    </div>
    	</nav>

        <!-- Page Content  -->
      <div>
        
      </div>
    
      </div>
		</div>

    

    <br>
    <br>
    

<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="js/bootstrap.js"></script>
    <!-- <script src="js/jquery.js"></script> 
	<script src="js/popper.js"></script> 
	<script src="js/bootstrap.js"></script> -->

    <script src="images/sidebar-05/js/jquery.min.js"></script>
    <script src="images/sidebar-05/js/popper.js"></script>
    <script src="images/sidebar-05/js/bootstrap.min.js"></script>
    <script src="images/sidebar-05/js/main.js"></script>
</body>

</html>