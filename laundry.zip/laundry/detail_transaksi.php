<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script defer src="fontawesome5/svg-with-js/js/fontawesome-all.min.js"></script>
    <link rel="shortcut icon" href="images/logo.PNG">
    <link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.css">
    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800,900" rel="stylesheet">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="images/sidebar-05/css/style.css">
    <link rel="stylesheet" href="gaya.css">
    <link href="//netdna.bootstrapcdn.com/bootstrap/3.0.3/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <script src="//netdna.bootstrapcdn.com/bootstrap/3.0.3/js/bootstrap.min.js"></script>
    <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
    <title>transaksi</title>
</head>
<body>
    
<!-- Sidebar -->
	
<div class="wrapper d-flex align-items-stretch">
			<nav id="sidebar">
				<div class="custom-menu">
					<button type="button" id="sidebarCollapse" class="btn btn-primary">
	          <i class="fa fa-bars"></i>
	          <span class="sr-only">laundry Menu</span>
	        </button>
        </div>
				<div class="p-4">
		  		<h1><a href="#" class="logo">laundry<span>layanan untuk anda</span></a></h1>
	        <ul class="list-unstyled components mb-5">
                
	          <li class="active">
	            <a href="admin.php"><span class="fa fa-home mr-3"></span> Home</a>
	          </li>
              <li>
              <a href="transaksi.php"><span class="fa fa-money-bill-alt mr-3"></span>transaksi</a>
              </li>
              
	          <li>
              <a href="works.php"><span class="fa fa-briefcase mr-3"></span> cabang kami</a>
</li>
	        
             
              
	        </ul>

	        <div class="mb-5">
						
</form>
	</div>
    </div>
    </nav><br>
<div id="content" class="p-4 p-md-5 pt-5">

        <div class="panel panel-default" style="border-radius: 10px;">
          <div class="panel-heading">
<p>detail trantsaksi</p><a href="admin.php" style="text-align-last: left">beranda /</a>
<a href="form_tambah_paket.php">tambah paket</a>
          </div>
        
    <br>
    <table class="table table-border">
    <thead>
    <tr>
        <center>
        <th>Id outlet</th>
        <th>Nama</th>
        <th>Alamat</th>
        <th>Telpon</th>
        <th>Aksi</th>
        
    </tr>
    </thead>
 

<?php


    include "db.php";
   
    $db = new Database();
    $data = $db->getAll('detai_transaksi');

foreach($data as $d):
?>
   
<tr>
   
   <td> <?= $d['id_detail']; ?></td>
   <td> <?= $d['id_transaksi']; ?></td>
   <td> <?= $d['id_paket']; ?></td>
   <td> <?= $d['quantity']; ?></td>  
   <td>
    <a href="outlet/ubah_outlet.php?id=<?php echo $d['id_outlet'];?>"class='btn btn-primary btn-md'>ubah</a>   
    
    <a href="outlet/proses_hapus_outlet.php?id=<?php echo $d['id_outlet'];?>" onclick="return confirm ('yakin menghapus?')"class='btn btn-danger btn-md'>hapus</a>
   </td><center>
   
</tr>
<?php endforeach; ?>

    </table>
  
<br>

    </div>
    </div>
    </div>
      
</div>

<script src="images/sidebar-05/js/jquery.min.js"></script>
    <script src="images/sidebar-05/js/popper.js"></script>
    <script src="images/sidebar-05/js/bootstrap.min.js"></script>
    <script src="images/sidebar-05/js/main.js"></script>

</body>
</html>