<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.css">
    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800,900" rel="stylesheet">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="images/sidebar-05/css/style.css">
    <link href="//netdna.bootstrapcdn.com/bootstrap/3.0.3/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <script src="//netdna.bootstrapcdn.com/bootstrap/3.0.3/js/bootstrap.min.js"></script>
    <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
    <link href="https://fonts.googleapis.com/css?family=Varela+Round" rel="stylesheet">
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<title>Admin</title>
<style>
.fa-facebook{
    background: #3b5998;
    color: white;
}
.fa-twitter{
    background: #55acee;
    color: white;
}
.fa-google{
    background: #dd4b39;
    color: white;
}
.fa-instagram{
    background: #125688;
    color: white;
}
.fa-whatsapp{
    background: greenyellow;
    color: white;
}
</style>
</head>

<body  class="fixed-left">

<!-- Sidebar -->
	
<div class="wrapper d-flex align-items-stretch">
			<nav id="sidebar">
				<div class="custom-menu">
					<button type="button" id="sidebarCollapse" class="btn btn-primary ">
	          <i class="fa fa-bars "></i>
	          <span class="sr-only">laundry Menu</span>
	        </button>
        </div>
				<div class="p-4">
		  		<h1><a href="#" class="logo">laundry<span>layanan untuk anda</span></a></h1>
	        <ul class="list-unstyled components mb-5">
	          <li class="active">
	            <a href="admin.php"><span class="fa fa-home mr-3"></span> Home</a>
	          </li>
              <li>
              <a href="transaksi.php"><span class="fa fa-money mr-3"></span>transaksi</a>
              </li>
              
	          <li>
              <a href="works.php"><span class="fa fa-briefcase mr-3"></span> cabang kami</a>
	          </li>				
            <li>
              <a href="proses_logout.php" style="height: toggle;"><span class="fa fa-power-off mr-3"></span> logout</a>
	          </li>
              
            </ul>
          

	        <div class="mb-6">
            <a href="#" class="fa fa-facebook" style="font-size: 30px; margin: 5px 2px; padding:20px;"></a>
            <a href="#" class="fa fa-twitter"style="font-size: 30px; margin: 5px 2px; padding:20px"></a>
            <a href="#" class="fa fa-google" style="font-size: 30px; margin: 5px 2px; padding:20px"></a>
            <a href="#" class="fa fa-instagram" style="font-size: 30px; margin: 5px 2px; padding:20px"></a>	
            <a href="#" class="fa fa-whatsapp" style="font-size: 30px; margin: 5px 2px; padding:20px"></a>				
</form>

	</div>
    </div>
    </nav>



        <!-- Page Content  -->
      
        <br><br>
      <div id="content" class="p-4 p-md-5 pt-5">
          
      <div class="row">
          <div class="col-sm-3">
              <div class="card-deck">
                <div class="card bg-primary text-white">
                    <div class="card-body"><center>
                        <p><i class="fa fa-users fa-3x"></i></p>
                        <h3>11+</h3>
                        <p>Partner</p>
                    </div></center>
                </div>  
              </div>
          </div>

          
          <div class="col-sm-3">
              <div class="card-deck">
                <div class="card bg-warning text-white""> 
                    <div class="card-body"><center>
                    <p><i class="fa fa-user-circle fa-3x"></i></p>
                        <h3>20+</h3>
                        <p>Member</p>
                        </div></center>
                </div>  
              </div>
          </div>
          
          <div class="col-sm-3">
              <div class="card-deck">
                <div class="card bg-success text-white"">
                <div class="card-body"><center>
                    <p><i class="fa fa-check fa-3x"></i></p>
                        <h3>55+</h3>
                        <p>Projecks</p>
                        </div></center>
                </div>  
              </div>
          </div>
          
          <div class="col-sm-3">
              <div class="card-deck">
                <div class="card bg-info text-white"">
                <div class="card-body"><center>
                    <p><i class="fa fa-building fa-3x"></i></p>
                        <h3>12+</h3>
                        <p>Cabang Kami</p>
                        </div></center>
                </div>  
              </div>
          </div>
      </div><br>
<div class="card">
    <div class="card-body"><p>Selamat <b>Datang </b>  </p></div>
</div>
    <br>
        <div class="panel panel-primary" style="border-radius: 10px;">
        <h3 style="border-right-width: 10%">  Halaman member</h3>
          <div class="panel-heading">   
        <div class="table-wrapper">			
                <div class="row">
                    <div class="col-sm-4">
						<div class="show-entries">
							<span>Show</span>
							<select>
								<option>5</option>
								<option>10</option>
								<option>15</option>
								<option>20</option>
							</select>
							<span>entries</span>
						</div>						
					</div>
					<div class="col-sm-4">
						<h2 class="text-center"> <b></b></h2>
					</div>
                    <div class="col-sm-4">
                        <div class="search-box">
							<div class="input-group">
								<span class="input-group-addon"><i class="fa fa-search"></i></span>
								<input type="text" class="form-control" placeholder="Search&hellip;">
							</div>
                        </div>
                    </div>
                </div>
            </div>
          <div class="panel-body">
    
    <br>
    <table class="table table-border">
        
<thead>

        <th>Id Member</th>
        <th>Nama</th>
        <th>Alamat</th>
        <th>Jenis kelamin</th>
        <th>No.Telpon</th>
        <th>aksi</th>
    </tr>
</thead>
</center>
   <?php

    include "db.php";
   
    $db = new Database();
    $data = $db->getAll('member');

foreach($data as $d):
?>
   
   <tr>
   
   <td> <?= $d['id_member']; ?></td>
   <td> <?= $d['nama']; ?></td>
   <td> <?= $d['alamat']; ?></td>
   <td> <?= $d['jenis_kelamin']; ?></td>
   <td> <?= $d['no_telpon']; ?></td>
   <td>
    <a href="ubah_member.php?id=<?php echo $d['id_member'];?>"class='btn btn-primary btn-md'>ubah</a>   
    
    <a href="hapus_member.php?id=<?php echo $d['id_member'];?>" onclick="return confirm ('yakin menghapus?')"class='btn btn-danger'>hapus</a>
   </td>
   
</tr>
<?php endforeach; ?>

    </table>
  
<br>
<a href="tambah_member.php"class='btn btn-primary btn-lg' style="text-align: left;">Tambah member</a>
    </div>
    </div>
    </div>
<br>


    <script src="images/sidebar-05/js/jquery.min.js"></script>
    <script src="images/sidebar-05/js/popper.js"></script>
    <script src="images/sidebar-05/js/bootstrap.min.js"></script>
    <script src="images/sidebar-05/js/main.js"></script>
</body>

</html>