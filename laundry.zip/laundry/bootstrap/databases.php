<?php

$nama_host ='localhost';
$username  ='root';
$password  ='';
$database  ="butuhmakan";

$koneksi=mysqli_connect($nama_host,$username,$password,$database);

if (mysqli_connect_errno()){
    echo"Salah euy hampura
    <br>". mysqli_connect_error($koneksi);
}

?>